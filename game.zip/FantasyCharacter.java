package com.asgn6.game;

abstract class FantasyCharacter {
    WalkBehavior walkBehavior;
    FlyBehavior flyBehavior;

    public FantasyCharacter(WalkBehavior walkBehavior, FlyBehavior flyBehavior){
        this.walkBehavior = walkBehavior;
        this.flyBehavior = flyBehavior;
    }

    public FantasyCharacter(WalkBehavior walkBehavior){
        this.walkBehavior = walkBehavior;
    }

    public FantasyCharacter(FlyBehavior flyBehavior){
        this.flyBehavior = flyBehavior;
    }

    public void walk()
    {
        walkBehavior.walk();
    }

    public void fly()
    {
        flyBehavior.fly();
    }

    public void setWalkBehavior(WalkBehavior walkBehavior)
    {
        this.walkBehavior = walkBehavior;
    }

    public void setFlyBehavior(FlyBehavior flyBehavior)
    {
        this.flyBehavior = flyBehavior;
    }

    public abstract void display();
}
