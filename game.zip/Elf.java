package com.asgn6.game;

public class Elf extends FantasyCharacter {
    public Elf(WalkBehavior walkBehavior) {
        super(walkBehavior);
    }

    @Override
    public void display() {
        System.out.println("I am Elf");
    }
}
