package com.asgn6.game;

public class Pegasus extends FantasyCharacter {
    public Pegasus(WalkBehavior walkBehavior, FlyBehavior flyBehavior) {
        super(walkBehavior, flyBehavior);
    }

    @Override
    public void display() {
        System.out.println("I am Pegasus");
    }
}
