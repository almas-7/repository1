package com.asgn6.game;

public class MagicFlying implements FlyBehavior {
    @Override
    public void fly() {
        System.out.println("I am flying with magic");
    }
}
