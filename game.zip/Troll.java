package com.asgn6.game;

public class Troll extends FantasyCharacter {
    public Troll(WalkBehavior walkBehavior) {
        super(walkBehavior);
    }

    @Override
    public void display() {
        System.out.println("I am Troll");
    }
}
