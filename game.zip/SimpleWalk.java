package com.asgn6.game;

public class SimpleWalk implements WalkBehavior {
    @Override
    public void walk() {
        System.out.println("I am walking");
    }
}
