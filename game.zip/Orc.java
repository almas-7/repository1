package com.asgn6.game;

public class Orc extends FantasyCharacter {
    public Orc(WalkBehavior walkBehavior) {
        super(walkBehavior);
    }

    @Override
    public void display() {
        System.out.println("I am Orc");
    }
}
