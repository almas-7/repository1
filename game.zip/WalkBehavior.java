package com.asgn6.game;

public interface WalkBehavior {
    public void walk();
}
