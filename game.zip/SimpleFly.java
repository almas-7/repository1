package com.asgn6.game;

public class SimpleFly implements FlyBehavior {
    @Override
    public void fly() {
        System.out.println("I am flying");
    }
}
