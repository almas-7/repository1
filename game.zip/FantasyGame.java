package com.asgn6.game;

public class FantasyGame {
    public static void main(String[] args) {
        WalkBehavior walk = new SimpleWalk();
        FlyBehavior fly = new SimpleFly();
        FlyBehavior magicFly = new MagicFlying();

        FantasyCharacter vampire = new Vampire(walk, magicFly);
        FantasyCharacter troll = new Troll(walk);
        FantasyCharacter orc = new Orc(walk);
        FantasyCharacter pegasus = new Pegasus(walk, fly);
        FantasyCharacter elf = new Elf(walk);

        vampire.display();
        vampire.fly();
        vampire.walk();

        System.out.println();

        troll.display();
        troll.walk();

        System.out.println();

        orc.display();
        orc.walk();

        System.out.println();

        pegasus.display();
        pegasus.setFlyBehavior(magicFly);
        pegasus.walk();
        pegasus.fly();

        System.out.println();

        elf.display();
        elf.walk();
    }
}