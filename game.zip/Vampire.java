package com.asgn6.game;

public class Vampire extends FantasyCharacter {
    public Vampire(WalkBehavior walkBehavior, FlyBehavior flyBehavior) {
        super(walkBehavior, flyBehavior);
    }

    @Override
    public void display() {
        System.out.println("I am Vampire");
    }
}
