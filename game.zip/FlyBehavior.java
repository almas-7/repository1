package com.asgn6.game;

public interface FlyBehavior {
    public void fly();
}
